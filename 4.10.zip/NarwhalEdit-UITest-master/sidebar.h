#ifndef SIDEBAR_H
#define SIDEBAR_H


#include <QWidget>
#include <QRect>

class Sidebar : public QRect
{

public:
    SideBar();

private slots:

};

#endif // SIDEBAR_H
