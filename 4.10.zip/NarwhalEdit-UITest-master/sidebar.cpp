#include "sidebar.h"
#include <QRect>

/*Sidebar::SideBar()
{
    QRect r1= new QRect(5, 5, 11, 16);
}*/
